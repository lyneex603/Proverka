package me.simplecheck;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class SimpleCheck extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final String PREFIX = "&8[&cПроверка&8] &f";
    private static final String PERM_USE = "simplecheck.use";

    /** Проверка: кого, кто и почему. */
    private record Check(UUID target, String targetName, UUID checker, String checkerName, String reason) {}

    /** Ключ - UUID проверяемого. */
    private final Map<UUID, Check> checks = new ConcurrentHashMap<>();
    /** Discord-контакты проверяющих (/check setdiscord). */
    private final Map<UUID, String> staffDiscord = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        getCommand("check").setExecutor(this);
        getCommand("check").setTabCompleter(this);
        getCommand("discord").setExecutor(this);
    }

    // ------------------------------------------------------------------ утилиты

    private void msg(CommandSender to, String text) {
        to.sendMessage(LEGACY.deserialize(PREFIX + text));
    }

    private boolean frozen(Player p) {
        return checks.containsKey(p.getUniqueId());
    }

    private void log(String type, Check c) {
        File f = new File(getDataFolder(), "history.log");
        try (FileWriter w = new FileWriter(f, StandardCharsets.UTF_8, true)) {
            w.write(LocalDateTime.now().format(FMT) + " | " + type + " | " + c.targetName()
                    + " | " + c.checkerName() + " | " + c.reason() + "\n");
        } catch (IOException ex) {
            getLogger().warning("Не удалось записать history.log: " + ex.getMessage());
        }
    }

    private Check findCheck(String name) {
        for (Check c : checks.values()) {
            if (c.targetName().equalsIgnoreCase(name)) return c;
        }
        return null;
    }

    private void runConsole(String template, String player) {
        if (template == null || template.isBlank()) return;
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), template.replace("%player%", player));
    }

    // ------------------------------------------------------------------ команды

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("discord")) {
            return handleDiscord(sender, args);
        }

        if (!sender.hasPermission(PERM_USE)) {
            msg(sender, "&cУ тебя нет прав.");
            return true;
        }
        if (args.length == 0) {
            help(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "list" -> {
                if (checks.isEmpty()) {
                    msg(sender, "Активных проверок нет.");
                    return true;
                }
                msg(sender, "Активные проверки:");
                for (Check c : checks.values()) {
                    sender.sendMessage(LEGACY.deserialize("&7 - &e" + c.targetName() + " &7(проверяет &f"
                            + c.checkerName() + "&7): " + c.reason()));
                }
            }
            case "release" -> finish(sender, args, "END", null, "&aИгрок отпущен.");
            case "ban" -> finish(sender, args, "BAN", getConfig().getString("ban-command"), "&cИгрок забанен.");
            case "confess" -> finish(sender, args, "CONFESS", getConfig().getString("confess-command"),
                    "&cИгрок признался, выдан уменьшенный бан.");
            case "transfer" -> transfer(sender, args);
            case "history" -> history(sender, args);
            case "setdiscord" -> {
                if (!(sender instanceof Player p)) {
                    msg(sender, "Только для игроков.");
                    return true;
                }
                if (args.length < 2) {
                    msg(sender, "&cИспользование: /check setdiscord <текст>");
                    return true;
                }
                String contact = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
                staffDiscord.put(p.getUniqueId(), contact);
                msg(sender, "Твой Discord для проверок: &e" + contact);
            }
            default -> start(sender, args);
        }
        return true;
    }

    private void help(CommandSender s) {
        msg(s, "Команды:");
        String[] lines = {
                "/check <игрок> [причина] &7- начать проверку",
                "/check release <игрок> &7- отпустить",
                "/check ban <игрок> &7- забанить",
                "/check confess <игрок> &7- бан с уменьшенным сроком",
                "/check transfer <игрок> <проверяющий> &7- передать проверку",
                "/check list &7- активные проверки",
                "/check history <игрок> &7- последние проверки",
                "/check setdiscord <текст> &7- твой Discord"
        };
        for (String l : lines) s.sendMessage(LEGACY.deserialize("&e" + l));
    }

    private void start(CommandSender sender, String[] args) {
        if (!(sender instanceof Player checker)) {
            msg(sender, "Только для игроков.");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            msg(sender, "&cИгрок не найден.");
            return;
        }
        if (target.equals(checker)) {
            msg(sender, "&cНельзя проверять себя.");
            return;
        }
        if (target.hasPermission("simplecheck.bypass")) {
            msg(sender, "&cУ игрока иммунитет от проверки.");
            return;
        }
        if (frozen(target)) {
            msg(sender, "&cЭтот игрок уже на проверке.");
            return;
        }

        String reason = args.length > 1
                ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length))
                : "не указана";
        Check c = new Check(target.getUniqueId(), target.getName(), checker.getUniqueId(), checker.getName(), reason);
        checks.put(target.getUniqueId(), c);
        target.leaveVehicle();
        log("START", c);

        msg(checker, "Проверка &e" + target.getName() + "&f начата. Пока она идёт, твой чат приватный: его видит только проверяемый.");
        target.sendMessage(Component.empty());
        msg(target, "&cТы вызван на проверку на читы!");
        msg(target, "Проверяющий: &e" + checker.getName());
        String discord = staffDiscord.get(checker.getUniqueId());
        if (discord != null) msg(target, "Discord проверяющего: &e" + discord);
        msg(target, "Двигаться нельзя. Писать можно только в чат (его видит только проверяющий). "
                + "Свой Discord: &e/discord <контакт>");
        msg(target, "&7Выход с сервера считается отказом от проверки.");
    }

    private void finish(CommandSender sender, String[] args, String logType, String consoleCmd, String done) {
        if (args.length < 2) {
            msg(sender, "&cУкажи игрока.");
            return;
        }
        Check c = findCheck(args[1]);
        if (c == null) {
            msg(sender, "&cТакой проверки нет.");
            return;
        }
        checks.remove(c.target());
        log(logType, c);
        runConsole(consoleCmd, c.targetName());

        msg(sender, done);
        Player t = Bukkit.getPlayer(c.target());
        if (t != null && logType.equals("END")) {
            msg(t, "&aПроверка завершена, ты свободен.");
        }
    }

    private void transfer(CommandSender sender, String[] args) {
        if (args.length < 3) {
            msg(sender, "&cИспользование: /check transfer <игрок> <проверяющий>");
            return;
        }
        Check c = findCheck(args[1]);
        Player newChecker = Bukkit.getPlayerExact(args[2]);
        if (c == null) {
            msg(sender, "&cТакой проверки нет.");
            return;
        }
        if (newChecker == null || !newChecker.hasPermission(PERM_USE)) {
            msg(sender, "&cПроверяющий не найден или у него нет прав.");
            return;
        }
        Check updated = new Check(c.target(), c.targetName(), newChecker.getUniqueId(), newChecker.getName(), c.reason());
        checks.put(c.target(), updated);
        log("TRANSFER", updated);

        msg(sender, "Проверка передана &e" + newChecker.getName());
        msg(newChecker, "Тебе передана проверка игрока &e" + c.targetName() + "&f. Причина: " + c.reason());
        Player t = Bukkit.getPlayer(c.target());
        if (t != null) msg(t, "Теперь тебя проверяет &e" + newChecker.getName());
    }

    private void history(CommandSender sender, String[] args) {
        if (args.length < 2) {
            msg(sender, "&cУкажи игрока.");
            return;
        }
        File f = new File(getDataFolder(), "history.log");
        if (!f.exists()) {
            msg(sender, "История пуста.");
            return;
        }
        try {
            List<String> found = new ArrayList<>();
            for (String line : Files.readAllLines(f.toPath(), StandardCharsets.UTF_8)) {
                if (line.toLowerCase().contains("| " + args[1].toLowerCase() + " |")) found.add(line);
            }
            if (found.isEmpty()) {
                msg(sender, "По игроку записей нет.");
                return;
            }
            for (String line : found.subList(Math.max(0, found.size() - 10), found.size())) {
                sender.sendMessage(LEGACY.deserialize("&7" + line));
            }
        } catch (IOException ex) {
            msg(sender, "&cНе удалось прочитать историю.");
        }
    }

    private boolean handleDiscord(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (!p.hasPermission("simplecheck.discord")) {
            msg(p, "&cУ тебя нет прав.");
            return true;
        }
        Check c = checks.get(p.getUniqueId());
        if (c == null) {
            msg(p, "&cТы сейчас не на проверке.");
            return true;
        }
        if (args.length == 0) {
            msg(p, "&cИспользование: /discord <контакт>");
            return true;
        }
        Player checker = Bukkit.getPlayer(c.checker());
        String contact = String.join(" ", args);
        if (checker != null) msg(checker, "Discord игрока &e" + p.getName() + "&f: &b" + contact);
        msg(p, "Discord отправлен проверяющему.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        if (!cmd.getName().equalsIgnoreCase("check") || !sender.hasPermission(PERM_USE)) return out;
        if (args.length == 1) {
            out.addAll(List.of("list", "release", "ban", "confess", "transfer", "history", "setdiscord"));
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if (args.length == 2 || args.length == 3) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        String last = args[args.length - 1].toLowerCase();
        out.removeIf(s -> !s.toLowerCase().startsWith(last));
        return out;
    }

    // ------------------------------------------------------------------ чат

    /**
     * LOWEST + полная отмена: сообщения во время проверки идут только в приватный чат
     * проверяющий <-> проверяемый, поэтому мут от других плагинов не мешает.
     */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        String text = PlainTextComponentSerializer.plainText().serialize(e.message());

        Check own = checks.get(p.getUniqueId());
        if (own != null) {
            e.setCancelled(true);
            Component line = LEGACY.deserialize("&8[&cЧек&8] &e" + p.getName() + "&7: &f").append(Component.text(text));
            p.sendMessage(line);
            Player checker = Bukkit.getPlayer(own.checker());
            if (checker != null) checker.sendMessage(line);
            return;
        }

        List<Check> mine = new ArrayList<>();
        for (Check c : checks.values()) {
            if (c.checker().equals(p.getUniqueId())) mine.add(c);
        }
        if (mine.isEmpty()) return;

        e.setCancelled(true);
        Component line = LEGACY.deserialize("&8[&cЧек&8] &a" + p.getName() + "&7: &f").append(Component.text(text));
        p.sendMessage(line);
        for (Check c : mine) {
            Player t = Bukkit.getPlayer(c.target());
            if (t != null) t.sendMessage(line);
        }
    }

    @EventHandler
    public void onCommandUse(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!frozen(p)) return;
        String cmd = e.getMessage().substring(1).split(" ")[0].toLowerCase();
        int colon = cmd.indexOf(':');
        if (colon >= 0) cmd = cmd.substring(colon + 1);
        if (!getConfig().getStringList("allowed-commands").contains(cmd)) {
            e.setCancelled(true);
            msg(p, "&cВо время проверки команды запрещены.");
        }
    }

    // ------------------------------------------------------------------ заморозка

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!frozen(e.getPlayer())) return;
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()
                || from.getYaw() != to.getYaw() || from.getPitch() != to.getPitch()) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        if (!frozen(e.getPlayer())) return;
        // Разрешаем только телепорты от команд и плагинов (например, модератор забрал игрока)
        PlayerTeleportEvent.TeleportCause cause = e.getCause();
        if (cause != PlayerTeleportEvent.TeleportCause.COMMAND && cause != PlayerTeleportEvent.TeleportCause.PLUGIN) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && frozen(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInvClick(InventoryClickEvent e) {
        if (e.getWhoClicked() instanceof Player p && frozen(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInvOpen(InventoryOpenEvent e) {
        if (e.getPlayer() instanceof Player p && frozen(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && frozen(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamageBy(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player p && frozen(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onHunger(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && frozen(p)) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ вход / выход

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        Check c = checks.get(p.getUniqueId());
        if (c != null) {
            Player checker = Bukkit.getPlayer(c.checker());
            if (checker != null) msg(checker, "&c" + p.getName() + " вышел во время проверки!");
            log("QUIT", c);
            String quitCmd = getConfig().getString("quit-command", "");
            if (quitCmd != null && !quitCmd.isBlank()) {
                checks.remove(p.getUniqueId());
                runConsole(quitCmd, p.getName());
            }
        }
        staffDiscord.remove(p.getUniqueId());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (frozen(p)) {
            msg(p, "&cТы всё ещё на проверке. Дождись проверяющего.");
            Check c = checks.get(p.getUniqueId());
            Player checker = Bukkit.getPlayer(c.checker());
            if (checker != null) msg(checker, "&e" + p.getName() + " вернулся на сервер.");
        }
    }
}
